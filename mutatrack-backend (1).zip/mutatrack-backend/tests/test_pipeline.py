"""Uji pipeline 6 tahap langsung (tanpa API & tanpa Supabase).
Jalankan dari folder utama repo:  python tests/test_pipeline.py
"""
import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
from pipeline import run_pipeline  # noqa: E402

DATA = Path.home() / "mutatrack-test"
R1, R2, REF = DATA / "test_R1.fastq.gz", DATA / "test_R2.fastq.gz", DATA / "ref.fna"
WORK = DATA / "hasil_uji"
SNPEFF_DB = "Escherichia_coli_str_k_12_substr_mg1655_gca_000005845"
EXPECTED = 2240  # jumlah varian acuan pada data simulasi seed 42

for f in (R1, R2, REF):
    if not f.exists():
        sys.exit(f"File tidak ada: {f}\nJalankan dulu: bash tests/make_test_data.sh")

shutil.rmtree(WORK, ignore_errors=True)
WORK.mkdir(parents=True)
t0 = time.time()
rows = run_pipeline(
    WORK, R1, R2, REF, {}, SNPEFF_DB, 2,
    on_stage=lambda s: print(f"TAHAP: {s}  ({time.time()-t0:.0f} dtk)", flush=True),
    on_stats=lambda s: None,
)
print(f"\nTOTAL VARIAN: {len(rows)}   (acuan: {EXPECTED})")
print("STATUS:", "SESUAI ACUAN" if len(rows) == EXPECTED else "BERBEDA dari acuan - cek versi tool / data uji")
for r in rows[:5]:
    print(r)
print(f"\nWaktu total: {time.time()-t0:.0f} detik")
print(f"Hasil lengkap ada di: {WORK}/out/annotated.vcf")

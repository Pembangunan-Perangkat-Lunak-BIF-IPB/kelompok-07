#!/usr/bin/env bash
# Membuat data uji SIMULASI yang identik di setiap perangkat (seed tetap = 42).
# Hasil: ~/mutatrack-test/{ref.fna,test_R1.fastq.gz,test_R2.fastq.gz,mutations.txt}
set -e
D="$HOME/mutatrack-test"
mkdir -p "$D" && cd "$D"
if [ ! -s ref.fna ]; then
  wget -O ref.fna.gz "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/GCA_000005845.2_ASM584v2_genomic.fna.gz"
  gunzip -f ref.fna.gz
fi
wgsim -N 300000 -1 150 -2 150 -e 0.001 -r 0.001 -R 0.15 -S 42 \
  ref.fna test_R1.fastq test_R2.fastq > mutations.txt
gzip -f test_R1.fastq test_R2.fastq
echo "mutasi tersisip: $(wc -l < mutations.txt)   (harus 4654)"
ls -lh "$D"

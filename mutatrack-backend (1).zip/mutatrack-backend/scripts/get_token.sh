#!/usr/bin/env bash
# Mengambil token login Supabase untuk dipakai di /docs (tombol Authorize).
# Jalankan:  bash scripts/get_token.sh
set -e
cd "$(dirname "$0")/../src"
set -a; source .env; set +a
read -p "Email akun uji: " EM
read -s -p "Password: " PW; echo
read -p "Publishable key (sb_publishable_...): " PK
EM="$EM" PW="$PW" python - <<PY
import json, os, urllib.request, urllib.error
req = urllib.request.Request(
    os.environ["SUPABASE_URL"] + "/auth/v1/token?grant_type=password",
    data=json.dumps({"email": os.environ["EM"], "password": os.environ["PW"]}).encode(),
    headers={"apikey": "$PK", "Content-Type": "application/json"})
try:
    print("\nTOKEN (salin seluruhnya, tanpa kata Bearer):\n")
    print(json.load(urllib.request.urlopen(req))["access_token"])
except urllib.error.HTTPError as e:
    print("GAGAL:", e.read().decode())
PY

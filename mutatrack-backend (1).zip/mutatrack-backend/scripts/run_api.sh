#!/usr/bin/env bash
# Menjalankan server API MutaTrack.  Jalankan:  bash run_api.sh
cd "$(dirname "$0")/../src"
for d in "$HOME/miniconda3" "$HOME/miniforge3" "$HOME/anaconda3" "$HOME/mambaforge"; do
  [ -f "$d/etc/profile.d/conda.sh" ] && source "$d/etc/profile.d/conda.sh" && break
done
conda activate mutatrack
[ -f .env ] || { echo "File src/.env belum ada. Lihat README (Tingkat 2, langkah 5)."; exit 1; }
echo "API berjalan. Buka http://localhost:8000/docs   (hentikan: Ctrl+C)"
uvicorn main:app --host 0.0.0.0 --port 8000

#!/usr/bin/env bash
# Setup MutaTrack di Ubuntu/WSL2. Jalankan sekali:  bash setup.sh
set -e
cd "$(dirname "$0")/.."

echo ">>> [1/5] Paket dasar Ubuntu"
sudo apt update
sudo apt install -y curl wget git unzip build-essential

echo ">>> [2/5] Cek conda"
CONDA_SH=""
for d in "$HOME/miniconda3" "$HOME/miniforge3" "$HOME/anaconda3" "$HOME/mambaforge"; do
  [ -f "$d/etc/profile.d/conda.sh" ] && CONDA_SH="$d/etc/profile.d/conda.sh" && break
done
if [ -z "$CONDA_SH" ]; then
  echo "conda belum ada, memasang Miniforge..."
  wget -O /tmp/Miniforge3.sh "https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Linux-x86_64.sh"
  bash /tmp/Miniforge3.sh -b -p "$HOME/miniforge3"
  CONDA_SH="$HOME/miniforge3/etc/profile.d/conda.sh"
  "$HOME/miniforge3/bin/conda" init bash >/dev/null
fi
source "$CONDA_SH"

echo ">>> [3/5] Membuat environment 'mutatrack' (versi tool dikunci agar hasil sama)"
conda config --set channel_priority flexible >/dev/null 2>&1 || true
if conda env list | grep -q "^mutatrack "; then
  echo "environment sudah ada, dilewati."
else
  conda env create -y -f environment.yml
fi
conda activate mutatrack

echo ">>> [4/5] Library Python untuk API"
pip install -r src/requirements.txt

echo ">>> [5/5] Database anotasi SnpEff (E. coli K-12)"
snpEff download -v Escherichia_coli_str_k_12_substr_mg1655_gca_000005845 || \
  echo "(Jika gagal, ulangi nanti: snpEff download Escherichia_coli_str_k_12_substr_mg1655_gca_000005845)"

echo ""
echo ">>> Cek tool:"
for t in fastqc fastp bwa samtools bcftools snpEff wgsim; do
  command -v $t >/dev/null && echo "OK     $t" || echo "HILANG $t"
done
echo ""
echo ">>> SELESAI. Lanjut ke README bagian 3 (membuat data uji)."

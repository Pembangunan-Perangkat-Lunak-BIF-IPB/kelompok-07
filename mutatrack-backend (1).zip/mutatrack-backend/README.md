# MutaTrack Backend

Repo ini membuat kamu bisa menjalankan hal yang sama seperti progres minggu 7:
pipeline variant calling 6 tahap (FastQC → fastp → BWA+samtools → bcftools → filter → SnpEff)
dan API-nya (FastAPI + Supabase), dengan data uji simulasi yang **identik di semua perangkat**.

Ada dua tingkat. Tingkat 1 cukup untuk membuktikan hasil yang sama; tingkat 2 menambah API.

| Tingkat | Perlu Supabase? | Hasil acuan |
|---|---|---|
| 1. Uji pipeline | Tidak | **2.240 varian** teranotasi |
| 2. Uji API (Swagger) | Ya (proyek gratis milik sendiri) | file VCF yang sama (2.240 varian) |

## 0. Prasyarat
- Windows 10/11 dengan **WSL2 + Ubuntu** terpasang (PowerShell admin: `wsl --install -d Ubuntu`, restart, buat username/password Ubuntu).
- RAM 8 GB cukup. Ruang disk bebas minimal 10 GB. Internet aktif.
- Semua perintah di bawah diketik di **terminal Ubuntu**, bukan PowerShell.

## 1. Taruh folder ini di Ubuntu
Salin folder `mutatrack-backend` ke home Ubuntu. Dari file zip di Windows (misal di Downloads):
```bash
cp /mnt/c/Users/NAMA_WINDOWS_KAMU/Downloads/mutatrack-backend.zip ~
cd ~ && unzip -o mutatrack-backend.zip && cd mutatrack-backend
```

## 2. Pasang semua tool (sekali saja, ±10–20 menit)
```bash
bash scripts/setup.sh
```
Akhir output harus menampilkan `OK` untuk 7 tool (fastqc fastp bwa samtools bcftools snpEff wgsim).
Kalau script meminta kamu menutup dan membuka ulang terminal, lakukan, lalu jalankan `bash scripts/setup.sh` lagi.

## 3. Buat data uji (simulasi, seed tetap)
```bash
conda activate mutatrack
bash tests/make_test_data.sh
```
Harus tercetak `mutasi tersisip: 4654`. Data ada di `~/mutatrack-test`.

## 4. TINGKAT 1 — Uji pipeline langsung
```bash
python tests/test_pipeline.py
```
Hasil yang benar:
```
TAHAP: qc → trimming → alignment → variant_calling → filtering → annotation
TOTAL VARIAN: 2240   (acuan: 2240)
STATUS: SESUAI ACUAN
```
File hasil: `~/mutatrack-test/hasil_uji/out/annotated.vcf`.
Kalau angkanya berbeda sedikit, bandingkan versi tool (`conda list | grep -E "bwa|bcftools|samtools|fastp|snpeff"`), harus sama dengan `environment.yml`.

## 5. TINGKAT 2 — Uji API (opsional, butuh Supabase milik sendiri)
Setiap anggota membuat proyek Supabase gratis sendiri. **Jangan berbagi secret key.**

1. https://supabase.com → New project. Tunggu status **Healthy**.
2. **SQL Editor → New query**, tempel seluruh isi `database/schema.sql`, Run.
3. **Authentication → Users → Add user → Create new user**: isi email + password uji,
   **centang Auto Confirm User**.
4. **Project Settings → API Keys**: catat Project URL, *Publishable key* (`sb_publishable_...`), dan *Secret key* (`sb_secret_...`).
5. Isi `.env` (tanpa menampilkan secret key di layar):
   ```bash
   cd ~/mutatrack-backend
   cp config/env.example src/.env && chmod 600 src/.env
   read -p "Project URL (https://xxxx.supabase.co): " URL
   sed -i "s|^SUPABASE_URL=.*|SUPABASE_URL=$URL|" src/.env
   read -s -p "Secret key: " KEY; echo
   ```
   Saat muncul `Secret key:`, **tempel key (klik kanan)** lalu Enter — layar tetap kosong, itu normal. Lalu:
   ```bash
   sed -i "s|^SUPABASE_SERVICE_KEY=.*|SUPABASE_SERVICE_KEY=$KEY|" src/.env
   grep -c '^SUPABASE_SERVICE_KEY=sb_secret_' src/.env     # harus 1
   ```
6. Jalankan API: `cd ~/mutatrack-backend && bash scripts/run_api.sh` (biarkan terminal ini terbuka).
7. Terminal Ubuntu kedua: `cd ~/mutatrack-backend && bash scripts/get_token.sh` → salin token `eyJ...`.
8. Browser Windows: `http://localhost:8000/docs` → **Authorize** → tempel token (tanpa kata Bearer).
9. Uji berurutan:
   `POST /analyses` (nama bebas; r1=`test_R1.fastq.gz`, r2=`test_R2.fastq.gz`, reference=`ref.fna`; pilih file lewat dialog dengan alamat `\\wsl$\Ubuntu\home\NAMA_UBUNTU\mutatrack-test`)
   → salin `id` → `POST /analyses/{aid}/validate` → `POST /analyses/{aid}/run`
   → `GET /analyses/{aid}` berulang sampai `status: selesai` → `/summary`, `/variants`, `/download?format=vcf`.
   File VCF yang diunduh harus berisi 2.240 varian: `grep -vc '^#' namafile.vcf`.

## Struktur folder
```
mutatrack-backend/
├── README.md               panduan ini
├── .gitignore              mencegah .env & data besar ikut ter-upload
├── environment.yml         versi tool bioinformatika (dikunci)
├── src/                    kode utama
│   ├── main.py             API FastAPI (11 endpoint)
│   ├── pipeline.py         pipeline 6 tahap
│   └── requirements.txt    library Python
├── database/
│   └── schema.sql          tabel Supabase (profiles, analyses, variants) + RLS
├── config/
│   └── env.example         contoh konfigurasi (salin ke src/.env)
├── tests/
│   ├── make_test_data.sh   buat data uji simulasi (seed 42)
│   └── test_pipeline.py    uji pipeline langsung (acuan 2.240 varian)
├── scripts/
│   ├── setup.sh            pasang semua tool
│   ├── run_api.sh          jalankan server API
│   └── get_token.sh        ambil token login Supabase
└── docs/
    └── Laporan_Progres_MutaTrack.docx
```

## Masalah umum
| Gejala | Solusi |
|---|---|
| `conda: command not found` | Tutup & buka ulang terminal Ubuntu, atau `source ~/miniforge3/etc/profile.d/conda.sh` |
| `Permission denied` saat mengubah file | `chmod u+w namafile` (file dari zip Windows kadang read-only) |
| `invalid_credentials` saat ambil token | User belum dibuat di proyek *yang sama* dengan `SUPABASE_URL`, atau Auto Confirm belum dicentang |
| `Database error creating new user` | `schema.sql` belum dijalankan di proyek itu |
| Tidak ada tombol Authorize di /docs | Pastikan memakai `src/main.py` dari repo ini |
| Total varian beda dari 2.240 | Cek versi tool & pastikan `make_test_data.sh` mencetak 4654 |

## Keamanan
Jangan commit/kirim `.env` atau secret key. Kalau secret key sempat tertempel di chat/grup, buat key baru di Supabase dan hapus yang lama.
Data uji ini simulasi (E. coli K-12 MG1655, GCA_000005845.2), bukan data klinis.

-- Jalankan di Supabase: SQL Editor > New query > paste > Run
-- Aman dijalankan ulang (menghapus tabel lama). Gunakan hanya di proyek uji.
drop trigger if exists on_auth_user_created on auth.users;
drop function if exists handle_new_user();
drop table if exists variants;
drop table if exists analyses;
drop table if exists profiles;

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz default now(),
  nama text,
  role text not null default 'user' check (role in ('user','admin'))
);

create table analyses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  nama text not null,
  status text not null default 'draf',
  stage text,
  config jsonb default '{}'::jsonb,
  files jsonb default '{}'::jsonb,
  stats jsonb default '{}'::jsonb,
  error text,
  log_tail text
);

create table variants (
  id bigint generated always as identity primary key,
  created_at timestamptz default now(),
  analysis_id uuid not null references analyses(id) on delete cascade,
  chrom text, posisi bigint, ref text, alt text, tipe text,
  qual real, depth int, gen text, efek text, impact text
);
create index on variants (analysis_id);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, nama) values (new.id, new.raw_user_meta_data->>'nama');
  return new;
end; $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

alter table profiles enable row level security;
alter table analyses enable row level security;
alter table variants enable row level security;

create policy "profil sendiri" on profiles for select using (auth.uid() = id);
create policy "analisis sendiri" on analyses for select using (auth.uid() = user_id);
create policy "varian milik analisis sendiri" on variants for select
  using (exists (select 1 from analyses a where a.id = analysis_id and a.user_id = auth.uid()));

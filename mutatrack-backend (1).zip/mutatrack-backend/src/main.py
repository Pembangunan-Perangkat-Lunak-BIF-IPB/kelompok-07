"""API MutaTrack (FastAPI). Jalankan: uvicorn main:app --host 0.0.0.0 --port 8000"""
import csv
import io
import os
import shutil
import threading
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.responses import FileResponse, Response
from supabase import create_client

from pipeline import DEFAULT_CONFIG, STAGES, PipelineError, run_pipeline

load_dotenv()
DATA_DIR = Path(os.getenv("DATA_DIR", "./data")).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)
SNPEFF_DB = os.getenv("SNPEFF_DB", "")
THREADS = int(os.getenv("THREADS", "2"))
sb = create_client(os.environ["SUPABASE_URL"], os.environ["SUPABASE_SERVICE_KEY"])

app = FastAPI(title="MutaTrack API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in os.getenv("ALLOWED_ORIGINS", "").split(",") if o.strip()],
    allow_methods=["*"], allow_headers=["*"],
)

# Laptop 8 GB: hanya 1 pipeline berjalan pada satu waktu
RUN_LOCK = threading.Semaphore(1)


# ---------- Auth (FR-01, NFR04) ----------
bearer = HTTPBearer(auto_error=False)


def current_user(cred: HTTPAuthorizationCredentials = Depends(bearer)):
    if not cred or not cred.credentials:
        raise HTTPException(401, "Harus login terlebih dahulu.")
    try:
        res = sb.auth.get_user(cred.credentials)
        return res.user
    except Exception:
        raise HTTPException(401, "Sesi tidak valid atau kedaluwarsa. Silakan login ulang.")


def get_analysis(aid: str, user) -> dict:
    r = sb.table("analyses").select("*").eq("id", aid).eq("user_id", user.id).execute()
    if not r.data:
        raise HTTPException(404, "Analisis tidak ditemukan.")
    return r.data[0]


def update(aid: str, **fields):
    fields["updated_at"] = datetime.now(timezone.utc).isoformat()
    sb.table("analyses").update(fields).eq("id", aid).execute()


def adir(aid: str) -> Path:
    d = DATA_DIR / aid
    d.mkdir(parents=True, exist_ok=True)
    return d


# ---------- Endpoint ----------
@app.get("/health")
def health():
    return {"ok": True, "snpeff_db": SNPEFF_DB}


@app.get("/config/default")
def default_config():
    return DEFAULT_CONFIG


@app.post("/analyses")
def create_analysis(
    nama: str = Form(...),
    r1: UploadFile = File(...),
    reference: UploadFile = File(...),
    r2: UploadFile | None = File(None),
    user=Depends(current_user),
):
    row = sb.table("analyses").insert({"user_id": user.id, "nama": nama, "config": DEFAULT_CONFIG}).execute().data[0]
    d = adir(row["id"])
    files = {}
    for key, up in (("r1", r1), ("r2", r2), ("reference", reference)):
        if up is None or not up.filename:
            continue
        safe = Path(up.filename).name
        with open(d / safe, "wb") as out:
            shutil.copyfileobj(up.file, out)
        files[key] = safe
    update(row["id"], files=files)
    return {"id": row["id"], "files": files}


@app.post("/analyses/{aid}/validate")
def validate(aid: str, user=Depends(current_user)):
    a = get_analysis(aid, user)
    d = adir(aid)
    f = a["files"] or {}
    errors = []
    if "r1" not in f:
        errors.append("File FASTQ (R1) belum diunggah.")
    if "reference" not in f:
        errors.append("Reference genome (FASTA) belum diunggah.")
    for key in ("r1", "r2"):
        if key in f:
            err = _check_fastq(d / f[key])
            if err:
                errors.append(f"{f[key]}: {err}")
    if "reference" in f:
        err = _check_fasta(d / f["reference"])
        if err:
            errors.append(f"{f['reference']}: {err}")
    if errors:
        update(aid, status="tidak_valid", error="; ".join(errors))
        return {"valid": False, "errors": errors}
    update(aid, status="valid", error=None)
    return {"valid": True, "errors": []}


def _open(p: Path):
    import gzip
    return gzip.open(p, "rt") if p.suffix == ".gz" else open(p, "r")


def _check_fastq(p: Path):
    name = p.name.lower().replace(".gz", "")
    if not name.endswith((".fastq", ".fq")):
        return "ekstensi harus .fastq/.fq (boleh .gz)."
    try:
        with _open(p) as fh:
            lines = [fh.readline() for _ in range(4)]
    except Exception:
        return "berkas korup atau tidak dapat dibaca."
    if not lines[0].startswith("@") or not lines[2].startswith("+") or len(lines[1].strip()) != len(lines[3].strip()):
        return "format FASTQ tidak valid."
    return None


def _check_fasta(p: Path):
    if p.suffix.lower() not in (".fa", ".fasta", ".fna"):
        return "ekstensi harus .fa/.fasta/.fna."
    ids = set()
    try:
        with open(p) as fh:
            first = True
            for line in fh:
                if first:
                    if not line.startswith(">"):
                        return "format FASTA tidak valid (harus diawali '>')."
                    first = False
                if line.startswith(">"):
                    sid = line[1:].split()[0]
                    if sid in ids:
                        return f"ID sekuens ganda: {sid}."
                    ids.add(sid)
    except Exception:
        return "berkas korup atau tidak dapat dibaca."
    return None


@app.put("/analyses/{aid}/config")
def set_config(aid: str, config: dict, user=Depends(current_user)):
    get_analysis(aid, user)
    unknown = [k for k in config if k not in DEFAULT_CONFIG]
    if unknown:
        raise HTTPException(400, f"Parameter tidak dikenal: {', '.join(unknown)}")
    update(aid, config={**DEFAULT_CONFIG, **config})
    return {"ok": True}


@app.post("/analyses/{aid}/run")
def run(aid: str, user=Depends(current_user)):
    a = get_analysis(aid, user)
    if a["status"] not in ("valid", "gagal"):
        raise HTTPException(400, "Analisis hanya dapat dijalankan setelah input dinyatakan valid.")  # BR-03
    update(aid, status="berjalan", stage="qc", error=None, stats={})
    threading.Thread(target=_worker, args=(aid,), daemon=True).start()
    return {"status": "berjalan"}


def _worker(aid: str):
    with RUN_LOCK:
        a = sb.table("analyses").select("*").eq("id", aid).execute().data[0]
        d = adir(aid)
        f = a["files"]
        try:
            rows = run_pipeline(
                d, d / f["r1"], (d / f["r2"]) if "r2" in f else None, d / f["reference"],
                a["config"], SNPEFF_DB, THREADS,
                on_stage=lambda s: update(aid, stage=s),
                on_stats=lambda s: update(aid, stats=s),
            )
            for i in range(0, len(rows), 500):
                sb.table("variants").insert([{**r, "analysis_id": aid} for r in rows[i:i + 500]]).execute()
            update(aid, status="selesai", stage="annotation")
        except PipelineError as e:
            update(aid, status="gagal", error=str(e))
        except Exception as e:
            update(aid, status="gagal", error=f"Kesalahan tak terduga: {e}")
        finally:
            lp = d / "pipeline.log"
            if lp.exists():
                update(aid, log_tail="".join(lp.read_text().splitlines(True)[-60:]))


@app.get("/analyses")
def list_analyses(user=Depends(current_user)):
    r = sb.table("analyses").select("id,nama,status,stage,created_at").eq("user_id", user.id).order("created_at", desc=True).execute()
    return r.data


@app.get("/analyses/{aid}")
def get_one(aid: str, user=Depends(current_user)):
    a = get_analysis(aid, user)
    lp = DATA_DIR / aid / "pipeline.log"
    if a["status"] == "berjalan" and lp.exists():  # log live
        a["log_tail"] = "".join(lp.read_text().splitlines(True)[-60:])
    a["stages"] = STAGES
    return a


@app.get("/analyses/{aid}/summary")
def summary(aid: str, user=Depends(current_user)):
    a = get_analysis(aid, user)
    if a["status"] != "selesai":
        raise HTTPException(400, "Analisis belum selesai.")  # BR-07
    return a["stats"]


@app.get("/analyses/{aid}/variants")
def variants(aid: str, limit: int = 200, offset: int = 0, impact: str | None = None, user=Depends(current_user)):
    get_analysis(aid, user)
    q = sb.table("variants").select("*").eq("analysis_id", aid)
    if impact:
        q = q.eq("impact", impact.upper())
    return q.order("posisi").range(offset, offset + limit - 1).execute().data


@app.get("/analyses/{aid}/download")
def download(aid: str, format: str = "vcf", user=Depends(current_user)):
    a = get_analysis(aid, user)
    if a["status"] != "selesai":
        raise HTTPException(400, "File hasil belum tersedia.")  # BR-08
    d = DATA_DIR / aid
    if format == "vcf":
        return FileResponse(d / "out" / "annotated.vcf", filename=f"{a['nama']}.vcf")
    rows = sb.table("variants").select("*").eq("analysis_id", aid).order("posisi").execute().data
    if format == "csv":
        buf = io.StringIO()
        cols = ["chrom", "posisi", "ref", "alt", "tipe", "qual", "depth", "gen", "efek", "impact"]
        w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
        return Response(buf.getvalue(), media_type="text/csv",
                        headers={"Content-Disposition": f'attachment; filename="{a["nama"]}.csv"'})
    if format == "pdf":
        return Response(_make_pdf(a, rows), media_type="application/pdf",
                        headers={"Content-Disposition": f'attachment; filename="{a["nama"]}.pdf"'})
    raise HTTPException(400, "Format harus vcf, csv, atau pdf.")


def _make_pdf(a: dict, rows: list) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    y = 800
    def line(txt, size=10, dy=16):
        nonlocal y
        if y < 60:
            c.showPage(); y = 800
        c.setFont("Helvetica", size); c.drawString(50, y, txt); y -= dy
    line("Laporan Analisis MutaTrack", 16, 26)
    line(f"Nama analisis : {a['nama']}")
    line(f"Dibuat        : {a['created_at']}", dy=24)
    s = a.get("stats", {})
    al, an = s.get("alignment", {}), s.get("annotation", {})
    line("Ringkasan", 13, 20)
    line(f"Total reads: {al.get('total_reads')}   Terpetakan: {al.get('persen_terpetakan')}%")
    line(f"Total varian: {an.get('total_varian')}  (SNP {an.get('snp')}, INDEL {an.get('indel')})")
    line(f"Gen terdampak: {an.get('gen_terdampak')}   Per impact: {an.get('per_impact')}", dy=24)
    line("Daftar varian (maks. 100 pertama)", 13, 20)
    for r in rows[:100]:
        line(f"{r['chrom']}:{r['posisi']} {r['ref']}>{r['alt']} {r['tipe']} {r['gen'] or '-'} {r['efek'] or '-'} {r['impact'] or '-'}", 8, 12)
    c.save()
    return buf.getvalue()
